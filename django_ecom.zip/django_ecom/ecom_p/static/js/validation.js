function aswin(){
    name = document.forms["form1"]["name"].value;
    if (name=="")

    {
alert("pleace enter your username ")
    }
}